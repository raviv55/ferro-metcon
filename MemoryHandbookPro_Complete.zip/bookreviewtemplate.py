from reportlab.platypus import *
def add_review(story,styles):
 story.append(Paragraph("Book Review Template",styles["Heading1"]));story.append(PageBreak())

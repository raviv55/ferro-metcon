from reportlab.platypus import *
def add_wisdom(story,styles):
 story.append(Paragraph("Data→Information→Knowledge→Understanding→Wisdom",styles["Title"]));story.append(PageBreak())

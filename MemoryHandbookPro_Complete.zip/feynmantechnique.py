from reportlab.platypus import *
def add_feynman(story,styles):
 story.append(Paragraph("Feynman Technique",styles["Heading1"]));story.append(Paragraph("Learn, Explain, Identify Gaps, Simplify, Master",styles["BodyText"]));story.append(PageBreak())

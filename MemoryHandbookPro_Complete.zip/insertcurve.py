from reportlab.platypus import *
def add_curve(story,styles):
 story.append(Paragraph("Forgetting Curve",styles["Heading1"]));story.append(Image("forgetting_curve.png",width=400,height=220));story.append(PageBreak())

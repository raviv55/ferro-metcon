from reportlab.platypus import *
def add_second_brain(story,styles):
 story.append(Paragraph("Second Brain",styles["Heading1"]));story.append(Paragraph("Capture Organize Distill Express",styles["BodyText"]));story.append(PageBreak())

from reportlab.platypus import *
def add_reading_levels(story,styles):
 story.append(Paragraph("Four Levels of Reading",styles["Heading1"]));story.append(Paragraph("Elementary, Inspectional, Analytical, Syntopical",styles["BodyText"]));story.append(PageBreak())

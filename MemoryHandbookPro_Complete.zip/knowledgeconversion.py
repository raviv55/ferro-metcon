from reportlab.platypus import *
def add_knowledge_conversion(story,styles):
 story.append(Paragraph("Book→Information→Understanding→Knowledge→Application→Wisdom",styles["Title"]));story.append(PageBreak())

from reportlab.platypus import *
def add_memory_palace(story,styles):
 story.append(Paragraph("Memory Palace",styles["Heading1"]));story.append(Paragraph("Store concepts in imagined locations.",styles["BodyText"]));story.append(PageBreak())

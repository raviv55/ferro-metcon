import matplotlib.pyplot as plt
def create_forgetting_curve():
 d=[0,1,7,30,90];a=[100,60,40,20,10];b=[100,90,85,80,70]
 plt.plot(d,a,label="Without Review");plt.plot(d,b,label="With Review");plt.legend();plt.grid();plt.savefig("forgetting_curve.png");plt.close()

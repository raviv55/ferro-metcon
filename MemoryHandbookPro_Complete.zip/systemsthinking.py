from reportlab.platypus import *
def add_systems(story,styles):
 story.append(Paragraph("Systems Thinking",styles["Heading1"]));story.append(PageBreak())

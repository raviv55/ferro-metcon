def add_cover(story,styles):
 from reportlab.platypus import Paragraph,Spacer,PageBreak
 story.append(Paragraph("MASTERING MEMORY, KNOWLEDGE & WISDOM",styles["Title"]))
 story.append(Paragraph("AI Guruji Signature Edition",styles["Heading2"]))
 story.append(Spacer(1,20)); story.append(PageBreak())
